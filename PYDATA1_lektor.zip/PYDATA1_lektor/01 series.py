# # Import potrebnych knihoven
# import pandas as pd
# import numpy as np

# # Stazeni .csv souboru publikovaneho na github.com
# url = 'https://raw.githubusercontent.com/petrrozkosny/pydata/main/pydata_data.csv'
# df = pd.read_csv(url,delimiter = ';')
# # Filtrovani dataframe (je vysvetleno pozdeji)
# df = df.loc[df['NAME']=='RUZYNE']
# # Vyber jednoho sloupce z dataframe do promenne srazky, ktera ma typ pandas.core.series.Series
# srazky = df['PRCP']

# # Atribut dtype obsahuje informace o datovem typu hodnot Series, viz https://pandas.pydata.org/docs/reference/api/pandas.Series.dtype.html
# print(srazky.dtype)

# # Atribut shape obsahuje informace o poctu radku Series, viz https://pandas.pydata.org/docs/reference/api/pandas.Series.shape.html
# print(srazky.shape)

# # Nastaveni sloupce ['DATE'] coby indexu (štítku)
# srazky = srazky.set_axis(df['DATE'])

# # Metoda describe() vraci zakladni statisticke informace, viz https://pandas.pydata.org/docs/reference/api/pandas.Series.describe.html 
# print(srazky.describe())




# Import potrebnych knihoven
import pandas as pd
import numpy as np


# # Stazeni .csv souboru publikovaneho na github.com
# url = 'https://raw.githubusercontent.com/petrrozkosny/pydata/main/pydata_data.csv'
# df = pd.read_csv(url,delimiter = ';')
# # Filtrovani dataframe (je vysvetleno pozdeji)
# df = df[df['NAME']=='RUZYNE']
# # Vyber jednoho sloupce z dataframe do promenne srazky, ktera ma typ pandas.core.series.Series
# dest = df['PRCP']
# dest.index = df['DATE']

# # # menime datovy typ indexu z object na datetime¨

# dest.index = pd.to_datetime(dest.index)
# print(dest.index.dtype)
# print(dest.describe())

# # jak ulozit series do .csv
# dest.to_csv('dest.csv',header = True)
# dest.to_excel('dest.xlsx',header = True,index = False)

# # spocitat z promenne dest pocet vyskytu PRCP > 50
# dest_prselo_moc = dest[dest > 50]
# print(dest_prselo_moc.count())

ucastnici = ['Petr','Karel','Jana','Pavel','Josef']
ucastnici2 = ucastnici.copy()

ucastnici2.append('Jitka')