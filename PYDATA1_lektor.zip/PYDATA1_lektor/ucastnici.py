import pandas as pd


mesta =['Praha','Brno','Ostrava','Plzen','Olomouc']
pocet_obyvatel  = [1300000,380000,290000,170000,100000]

# Vytvoreni Series z listu
s = pd.Series(pocet_obyvatel,index=mesta)

'''
1. Za pomoci iloc vypište první (nultý) prvek Series
2. Za pomoci loc vypište hodnotu pro město Praha
3. Za pomoci loc vypište hodnoty pro města Praha až Ostrava
4. Vytvořte si booleanovsky vektor 'podminka' pro města s počtem obyvatel nad 200000
5. Vypište města s počtem obyvatel nad 200000 (tj. města splňující podmínku z bodu 4)
'''

# 1
print(s.iloc[0])
# 2
print(s.loc['Praha'])
# 3
print(s.loc['Praha':'Ostrava'])
# 4
podminka = s > 200000 # booleanovsky vektor
# 5
print(s[s > 200000]) # vypiseme ta mesta, jejichz hodnota je True v podmince

print(s.iloc[0:3])

