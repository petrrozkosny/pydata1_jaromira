# Import potrebnych knihoven
import pandas as pd
from matplotlib import pyplot as plt
# Stazeni .csv souboru publikovaneho na github.com
url = 'https://raw.githubusercontent.com/petrrozkosny/pydata/main/pydata_data.csv'
df = pd.read_csv(url,delimiter = ';')

df['DATE'] = pd.to_datetime(df['DATE'])

df['ROK'] =  df['DATE'].dt.year
df['MESIC'] = df['DATE'].dt.month

# suma srazek po letech a lokalitach

df_pivot_table = pd.pivot_table(df,values='PRCP',index=['ROK','MESIC'],columns='NAME',aggfunc=['sum','mean'])
print(df_pivot_table)