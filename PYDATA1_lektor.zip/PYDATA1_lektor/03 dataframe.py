# Import potrebnych knihoven
import pandas as pd
from matplotlib import pyplot as plt
# Stazeni .csv souboru publikovaneho na github.com
url = 'https://raw.githubusercontent.com/petrrozkosny/pydata/main/pydata_data.csv'
df = pd.read_csv(url,delimiter = ';')

df['DATE'] = pd.to_datetime(df['DATE'])

# Omezit df tak, aby obsahoval všechny řádky, ale pouze nultý až čtvrtý sloupec
df = df.iloc[:,:4]
# bool vektor, NAME je rovno RUZYNE
bool_vektor = df['NAME'] == 'RUZYNE'
df = df[bool_vektor]

# # ze sloupce PRCP vytvorime Series, v ni spocitame kumulativni srazky a ty vykreslime do spojnicoveho grafu
# s = df['PRCP']
# s = s.cumsum()
# s.plot.line()
#plt.show()
print(df.describe())
print(df.shape)

# v promenne df dosadit do indexu hodnoty ze sloupce DATE
df.index = df['DATE']
print(df.head())
df = df.drop('STATION',axis=1)
df['ROK'] = df.index.year
# pridani mesice
df = df.assign(MESIC = df.index.month)

df['NAME'] = df['NAME'].str.lower() # po vektoru menime text na mala pismena
#alternativa
df['NAME']  = df['NAME'].apply(lambda x: x.lower())

# funkce vracejici prvni tri pismena z textu

def prvni_tri_pismena(text):
    return text[:3]

df['PRVNITRIPISMENA'] = df['NAME'].apply(lambda x: prvni_tri_pismena(x))
print(df.head())

for i,r in df.iterrows():
    i['NAME'] = i['NAME'].upper()