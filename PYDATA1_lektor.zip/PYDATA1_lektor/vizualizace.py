from matplotlib import pyplot as plt
import pandas as pd

# Stazeni .csv souboru publikovaneho na github.com
url = "https://raw.githubusercontent.com/petrrozkosny/pydata/main/pydata_data.csv"
df = pd.read_csv(url, delimiter=';')
df['DATE'] = pd.to_datetime(df['DATE'])
df['YEAR'] = df['DATE'].dt.year
df = df.loc[df['NAME'] == 'RUZYNE']

# Agregace dat podle roku
aggr = df.groupby('YEAR', as_index=False)['PRCP'].sum()
mean = aggr['PRCP'].mean()
aggr['MEAN'] = mean  # Přidání průměrné hodnoty jako konstanty

# Barevné rozlišení podle průměru
aggr['COLOR'] = aggr['PRCP'].apply(lambda x: 'red' if x < mean else 'cyan')

# Vytvoření sloupcového grafu
ax = aggr.plot(kind='bar', x='YEAR', y='PRCP', color=aggr['COLOR'], label='Srážky [mm]')

# Přidání spojnicového grafu na stejnou osu (pro konstantní průměr v čase)
ax.plot(aggr['YEAR'], aggr['MEAN'], color='green', linewidth=3, label='Průměr [mm]')

# Zobrazení legendy
plt.legend()

# Zobrazení grafu
plt.show()
